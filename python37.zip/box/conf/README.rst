All configurations in this directory will be built into the Sync client. Only
put configuration file and settings into this directory if they must be used by
the Sync client.

To exclude a configuration from the build, put it into the ./dev/ subdirectory.
